export class Room {
  public id: number; 
  public name: string; 
  constructor(id=0,name="") {
   
  }
}
