import { Injectable } from '@angular/core';
import { User } from '../model/User';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  checkUser(user:User):boolean{
    alert("check user");
    if(user.email==="zensar@email.com" && user.password==="zensar"){
      return true;
    }
    return false;
  }
  
}
