import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  booking =[{
    "roomNo":"101",
    "charges":"200.00"
  },{
    "roomNo":"102",
    "charges":"200.00"
  },
  {
    "roomNo":"103",
    "charges":"200.00"
  }

]

  constructor() { }

 getAllRoomsForBooking(){
   return this.booking;
 }
 bookRoom():string{
   alert("Booking Success")
   return "Booking Success";
 }
}
